﻿

Partial Public Class dsObreiros
End Class
