﻿Public Class login1
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        
    End Sub

    Protected Sub ImageButton1_Click(sender As Object, e As ImageClickEventArgs) Handles ImageButton1.Click

        Dim mapeadorDeUsuario As New MapeadorDeUsuarios
        Dim usuario As New Usuario

        usuario.Usuario = UserName.Text
        usuario.Senha = Password.Text

        If mapeadorDeUsuario.UsuarioExiste(usuario) Then
            If mapeadorDeUsuario.Login(usuario) Then
                Session("usuarioLogado") = "sim"
                Response.Redirect("~/Paginas/Default.aspx")
            Else
                'lblErro.Text = "Usuário ou senha incorretos"
                'lblErro.Visible = True

            End If
        Else
            'lblErro.Text = "Usuário não cadastrado"
            'lblErro.Visible = True
        End If
    End Sub
End Class